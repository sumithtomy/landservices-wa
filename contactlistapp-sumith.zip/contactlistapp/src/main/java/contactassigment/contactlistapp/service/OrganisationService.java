package contactassigment.contactlistapp.service;

import java.util.List;

import contactassigment.contactlistapp.dto.OrganisationDTO;

public interface OrganisationService
{
  List<OrganisationDTO> listAll();
}
