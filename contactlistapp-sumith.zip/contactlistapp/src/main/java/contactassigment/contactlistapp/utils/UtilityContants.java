package contactassigment.contactlistapp.utils;

public class UtilityContants {

  public static final String EMPTY_STRING = "";
  public static final String SPACE = " ";
  public static final String  WILD_CARD_MATCHER="*";
  public static final String  SQL_WILD_CARD_MATCHER="%";

  public static final String GLOBAL_DATE_PATTERN = "dd-MM-yyyy";
  public static final String GLOBAL_DATE_TIME_PATTERN = "dd-MM-yyyy HH:mm:ss";

}
