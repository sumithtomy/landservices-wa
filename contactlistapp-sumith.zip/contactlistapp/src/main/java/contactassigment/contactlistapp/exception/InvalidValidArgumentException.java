package contactassigment.contactlistapp.exception;

public class InvalidValidArgumentException extends RuntimeException {

  public InvalidValidArgumentException(String string) {
    super(string);
  }

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
