package contactassigment.contactlistapp.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Organisation {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Access(AccessType.PROPERTY)
  private Integer id;

  @Column(nullable = false)
  private String name;

  @Column(nullable = false)
  private String abn;



  public Integer getId() {
    return id;
  }

  public void setId(
      Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(
      String name) {
    this.name = name;
  }

  public String getAbn() {
    return abn;
  }

  public void setAbn(
      String abn) {
    this.abn = abn;
  }



}
